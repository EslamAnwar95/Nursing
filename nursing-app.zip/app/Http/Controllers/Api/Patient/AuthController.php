<?php

namespace App\Http\Controllers\Api\Patient;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Patient\Auth\PatientRegisterRequest;
use App\Http\Requests\Patient\Auth\PatientLoginRequest;
use App\Models\Patient;
use App\Traits\HandlesPassportToken;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class AuthController extends Controller
{


    use HandlesPassportToken;

    public function register(PatientRegisterRequest $request)
    {
        try {
            // Step 1: Create the patient
            $paitent = Patient::create([
                'full_name' => $request->full_name,
                'email' => $request->email,
                'phone_number' => $request->phone_number,
                'password' => Hash::make($request->password),
            ]);

            $result = $this->issueAccessToken($request->email, $request->password, 'patients');

            if (!$result['success']) {
                return response()->json([
                    'status' => false,
                    'message' => $result['message'],
                    'errors' => $result['errors'] ?? null,
                ], $result['status']);
            }

            return response()->json([
                'status' => 201,
                'message' => 'Candidate registered and logged in successfully.',
                'data' => [
                    'token' => $result['token']
                ]
            ], 201);
        } catch (\Exception $e) {
            Log::error('Registration exception', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'status' => false,
                'message' => 'Something went wrong during registration.',
                'error' => $e->getMessage()
            ], 500);
        }
    }


    public function login(PatientLoginRequest $request)
    {
        try {
            $result = $this->issueAccessToken($request->email, $request->password, 'patients');

            if (!$result['success']) {
                return response()->json([
                    'status' => false,
                    'message' => $result['message'],
                    'errors' => $result['errors'] ?? null,
                ], $result['status']);
            }

            return response()->json([
                'status' => true,
                'message' => 'Login successful.',
                'data' => [
                    'token' => $result['token']
                ]
            ], 200);
        } catch (\Exception $e) {
          

            return response()->json([
                'status' => false,
                'message' => 'Something went wrong during login.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function profile(Request $request)
    {
        // Return authenticated patient's profile
    }
}
