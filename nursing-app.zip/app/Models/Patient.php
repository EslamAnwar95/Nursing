<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Laravel\Passport\HasApiTokens;
class Patient extends Authenticatable
{
    
    use HasApiTokens, Notifiable, HasFactory, SoftDeletes;


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'patients';
   
    protected $fillable = [
        'full_name',
        'email',
        'phone_number',
        'password',
        'date_of_birth',
        'gender',
        'national_id',
        'address',
        'medical_history',
        'emergency_contact_name',
        'emergency_contact_phone',
        'is_active',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];
    protected $casts = [
        'email_verified_at' => 'datetime',
        'date_of_birth' => 'date',
        'is_active' => 'boolean',
    ];
    public function getFullNameAttribute($value)
    {
        return ucwords(strtolower($value));
    }
    public function setFullNameAttribute($value)
    {
        $this->attributes['full_name'] = ucwords(strtolower($value));
    }
    public function getPhoneNumberAttribute($value)
    {
        return preg_replace('/\D/', '', $value);
    }
    public function setPhoneNumberAttribute($value)
    {
        $this->attributes['phone_number'] = preg_replace('/\D/', '', $value);
    }
    public function getEmailAttribute($value)
    {
        return strtolower($value);
    }
    public function setEmailAttribute($value)
    {
        $this->attributes['email'] = strtolower($value);
    }


}
